"""
Velora Animated Caption Engine
================================
Word-by-word popup captions rendered with Pillow + FFmpeg.
Works with Whisper word-level timestamp output.

Usage:
    python velora_captions.py --video input.mp4 --whisper transcript.json --output output.mp4
    python velora_captions.py --video input.mp4 --whisper transcript.json --style tiktok
    python velora_captions.py --demo  # generates a test video to preview styles

Whisper JSON format expected (from whisper.transcribe with word_timestamps=True):
    {
      "segments": [
        {
          "words": [
            {"word": "Hello", "start": 0.0, "end": 0.4},
            ...
          ]
        }
      ]
    }
"""

import argparse
import json
import math
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont

# ──────────────────────────────────────────────
# CONFIG: Caption styles
# ──────────────────────────────────────────────

@dataclass
class CaptionStyle:
    # Layout
    position: str = "bottom"          # "bottom" | "center" | "top"
    max_words_per_line: int = 4        # words shown at once
    padding_x: int = 40               # horizontal padding from edges
    bottom_offset: float = 0.18       # fraction from bottom (for "bottom" position)

    # Font
    font_path: str = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
    font_size: int = 72
    line_spacing: int = 12

    # Colors: (R, G, B, A)
    text_color: Tuple = (255, 255, 255, 255)       # white
    highlight_color: Tuple = (255, 220, 0, 255)    # yellow highlight for active word
    shadow_color: Tuple = (0, 0, 0, 180)           # drop shadow
    outline_color: Tuple = (0, 0, 0, 255)          # stroke around text
    bg_color: Optional[Tuple] = None               # None = no background pill

    # Animation
    animation: str = "popup"       # "popup" | "fade" | "bounce" | "none"
    popup_duration: float = 0.08   # seconds for popup scale animation
    fade_duration: float = 0.06    # seconds for fade-in

    # Stroke
    outline_width: int = 4

    # Shadow
    shadow_offset: Tuple = (3, 3)
    shadow_blur: int = 0           # 0 = sharp shadow


# Preset styles
STYLES = {
    "tiktok": CaptionStyle(
        position="center",
        max_words_per_line=3,
        font_size=80,
        text_color=(255, 255, 255, 255),
        highlight_color=(255, 220, 0, 255),
        outline_width=5,
        animation="popup",
        bottom_offset=0.45,
    ),
    "reels": CaptionStyle(
        position="bottom",
        max_words_per_line=4,
        font_size=68,
        text_color=(255, 255, 255, 255),
        highlight_color=(255, 180, 0, 255),
        outline_width=4,
        animation="popup",
        bottom_offset=0.15,
    ),
    "podcast": CaptionStyle(
        position="bottom",
        max_words_per_line=5,
        font_size=58,
        text_color=(255, 255, 255, 255),
        highlight_color=(100, 220, 255, 255),
        outline_width=3,
        animation="fade",
        bottom_offset=0.10,
    ),
    "bold": CaptionStyle(
        position="center",
        max_words_per_line=3,
        font_size=90,
        text_color=(255, 255, 255, 255),
        highlight_color=(255, 60, 60, 255),
        outline_width=6,
        animation="bounce",
        bottom_offset=0.45,
        shadow_color=(0, 0, 0, 220),
        shadow_offset=(4, 4),
    ),
}


# ──────────────────────────────────────────────
# DATA STRUCTURES
# ──────────────────────────────────────────────

@dataclass
class Word:
    text: str
    start: float
    end: float

@dataclass
class WordGroup:
    """A group of words shown together on screen."""
    words: List[Word]
    start: float   # when this group appears
    end: float     # when this group disappears

    def active_word_at(self, t: float) -> int:
        """Return index of word being spoken at time t, or -1."""
        for i, w in enumerate(self.words):
            if w.start <= t <= w.end:
                return i
        return -1


# ──────────────────────────────────────────────
# WHISPER PARSER
# ──────────────────────────────────────────────

def load_whisper_words(json_path: str) -> List[Word]:
    """Parse Whisper JSON with word_timestamps=True into Word list."""
    with open(json_path) as f:
        data = json.load(f)

    words = []
    for segment in data.get("segments", []):
        for w in segment.get("words", []):
            text = w["word"].strip()
            if not text:
                continue
            words.append(Word(
                text=text,
                start=float(w["start"]),
                end=float(w["end"]),
            ))
    return words


def group_words(words: List[Word], max_per_group: int = 4) -> List[WordGroup]:
    """Split word list into display groups."""
    groups = []
    i = 0
    while i < len(words):
        chunk = words[i:i + max_per_group]
        # extend group end to just before next group starts, or to word end
        group_end = chunk[-1].end
        if i + max_per_group < len(words):
            next_start = words[i + max_per_group].start
            # if gap > 0.3s, cut earlier; otherwise hold until next group
            if next_start - group_end > 0.3:
                group_end = chunk[-1].end
            else:
                group_end = next_start - 0.02
        groups.append(WordGroup(
            words=chunk,
            start=chunk[0].start,
            end=group_end,
        ))
        i += max_per_group
    return groups


# ──────────────────────────────────────────────
# FRAME RENDERER
# ──────────────────────────────────────────────

class CaptionRenderer:
    def __init__(self, width: int, height: int, style: CaptionStyle):
        self.W = width
        self.H = height
        self.style = style
        self.font = self._load_font(style.font_size)
        self.font_small = self._load_font(max(style.font_size - 8, 40))

    def _load_font(self, size: int) -> ImageFont.FreeTypeFont:
        try:
            return ImageFont.truetype(self.style.font_path, size)
        except Exception:
            # fallback
            try:
                return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", size)
            except Exception:
                return ImageFont.load_default()

    def _text_size(self, text: str, font) -> Tuple[int, int]:
        img = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(img)
        bbox = draw.textbbox((0, 0), text, font=font)
        return bbox[2] - bbox[0], bbox[3] - bbox[1]

    def _draw_word(self, draw: ImageDraw.Draw, text: str, x: int, y: int,
                   font, color: Tuple, scale: float = 1.0, alpha: float = 1.0):
        """Draw a single word with outline + shadow."""
        s = self.style
        # Apply alpha to colors
        def with_alpha(c, a):
            return (c[0], c[1], c[2], int(c[3] * a))

        text_col = with_alpha(color, alpha)
        shadow_col = with_alpha(s.shadow_color, alpha)
        outline_col = with_alpha(s.outline_color, alpha)

        # Shadow
        sx, sy = s.shadow_offset
        draw.text((x + sx, y + sy), text, font=font, fill=shadow_col)

        # Outline (stroke by drawing in 8 directions)
        ow = s.outline_width
        for dx in range(-ow, ow + 1):
            for dy in range(-ow, ow + 1):
                if dx == 0 and dy == 0:
                    continue
                if abs(dx) + abs(dy) > ow + 1:
                    continue
                draw.text((x + dx, y + dy), text, font=font, fill=outline_col)

        # Main text
        draw.text((x, y), text, font=font, fill=text_col)

    def render_group(self, group: WordGroup, t: float) -> Image.Image:
        """Render one word group at time t onto a transparent RGBA frame."""
        s = self.style
        img = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        active_idx = group.active_word_at(t)
        group_age = t - group.start   # how long this group has been visible

        words = group.words
        font = self.font

        # Measure all words
        word_sizes = []
        for w in words:
            ww, wh = self._text_size(w.text + " ", font)
            word_sizes.append((ww, wh))

        # Wrap into lines
        lines = []
        current_line = []
        current_w = 0
        max_w = self.W - s.padding_x * 2

        for i, (w, (ww, wh)) in enumerate(zip(words, word_sizes)):
            if current_w + ww > max_w and current_line:
                lines.append(current_line)
                current_line = [(i, w, ww, wh)]
                current_w = ww
            else:
                current_line.append((i, w, ww, wh))
                current_w += ww

        if current_line:
            lines.append(current_line)

        # Compute line height
        _, sample_h = self._text_size("Ag", font)
        line_h = sample_h + s.line_spacing
        total_h = line_h * len(lines)

        # Y position
        if s.position == "center":
            base_y = int(self.H * (1 - s.bottom_offset)) - total_h // 2
        elif s.position == "top":
            base_y = int(self.H * 0.08)
        else:  # bottom
            base_y = int(self.H * (1 - s.bottom_offset)) - total_h

        # Global group fade-in
        group_alpha = min(1.0, group_age / max(s.fade_duration, 0.01)) if s.animation == "fade" else 1.0

        for line_i, line in enumerate(lines):
            # Center the line horizontally
            line_w = sum(ww for _, _, ww, _ in line)
            line_x = (self.W - line_w) // 2
            y = base_y + line_i * line_h

            for word_i, word, ww, wh in line:
                is_active = (word_i == active_idx)
                color = s.highlight_color if is_active else s.text_color

                word_age = max(0, t - word.start)

                # Animation
                scale = 1.0
                alpha = group_alpha

                if s.animation == "popup":
                    if is_active:
                        # Popup: quick scale from 1.3 → 1.0
                        progress = min(1.0, word_age / s.popup_duration)
                        scale = 1.3 - 0.3 * progress  # 1.3 → 1.0
                        alpha = min(1.0, group_alpha)
                    else:
                        scale = 1.0

                elif s.animation == "bounce":
                    if is_active and word_age < s.popup_duration * 2:
                        # Bounce: overshoot then settle
                        progress = word_age / (s.popup_duration * 2)
                        scale = 1.0 + 0.25 * math.sin(progress * math.pi) * (1 - progress)

                elif s.animation == "fade":
                    if word_age < s.fade_duration:
                        alpha = min(1.0, word_age / s.fade_duration) * group_alpha

                # Draw with scale (approximate by adjusting position)
                if scale != 1.0:
                    fw, fh = self._text_size(word.text, font)
                    # Scale by adjusting y position (simpler than PIL transform)
                    scaled_font_size = int(s.font_size * scale)
                    scaled_font = self._load_font(scaled_font_size)
                    sw, sh = self._text_size(word.text, scaled_font)
                    draw_x = line_x + (fw - sw) // 2
                    draw_y = y + (wh - sh) // 2
                    self._draw_word(draw, word.text, draw_x, draw_y, scaled_font, color, scale, alpha)
                else:
                    self._draw_word(draw, word.text, line_x, y, font, color, 1.0, alpha)

                line_x += ww

        return img


# ──────────────────────────────────────────────
# VIDEO PIPELINE
# ──────────────────────────────────────────────

def get_video_info(video_path: str) -> Tuple[int, int, float, float]:
    """Returns (width, height, fps, duration)."""
    cmd = [
        "ffprobe", "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=width,height,r_frame_rate,duration",
        "-of", "json", video_path
    ]
    out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL)
    info = json.loads(out)
    stream = info["streams"][0]
    w = int(stream["width"])
    h = int(stream["height"])
    fps_parts = stream["r_frame_rate"].split("/")
    fps = float(fps_parts[0]) / float(fps_parts[1])
    duration = float(stream.get("duration", 0))
    return w, h, fps, duration


def burn_captions(
    video_path: str,
    words: List[Word],
    output_path: str,
    style: CaptionStyle,
    max_words_per_group: int = None,
):
    """Full pipeline: render caption overlay frames and composite onto video."""
    max_per = max_words_per_group or style.max_words_per_line
    groups = group_words(words, max_per)

    W, H, fps, duration = get_video_info(video_path)
    renderer = CaptionRenderer(W, H, style)

    print(f"Video: {W}x{H} @ {fps:.2f}fps, {duration:.1f}s")
    print(f"Words: {len(words)}, Groups: {len(groups)}")

    with tempfile.TemporaryDirectory() as tmpdir:
        overlay_dir = Path(tmpdir) / "frames"
        overlay_dir.mkdir()

        # Determine which frames need captions
        total_frames = int(duration * fps) + 1
        frame_groups = {}  # frame_num → WordGroup

        for group in groups:
            start_frame = int(group.start * fps)
            end_frame = int(group.end * fps)
            for fn in range(start_frame, end_frame + 1):
                frame_groups[fn] = group

        print(f"Rendering caption frames...")
        rendered = 0
        frame_list_path = Path(tmpdir) / "frames.txt"

        # We'll generate a sparse overlay video using ffmpeg image input
        # Strategy: render only frames that have captions, write as PNG sequence
        # then use ffmpeg overlay filter

        # For efficiency: render all frames at video fps
        batch_size = 100
        for fn in range(total_frames):
            t = fn / fps
            frame_path = overlay_dir / f"frame_{fn:06d}.png"

            if fn in frame_groups:
                group = frame_groups[fn]
                frame_img = renderer.render_group(group, t)
            else:
                # Transparent frame
                frame_img = Image.new("RGBA", (W, H), (0, 0, 0, 0))

            frame_img.save(frame_path, "PNG")
            rendered += 1

            if rendered % 50 == 0:
                print(f"  Rendered {rendered}/{total_frames} frames...", end="\r")

        print(f"\nCompositing with FFmpeg...")

        # Build FFmpeg command to overlay PNG sequence onto video
        cmd = [
            "ffmpeg", "-y",
            "-i", video_path,
            "-framerate", str(fps),
            "-i", str(overlay_dir / "frame_%06d.png"),
            "-filter_complex",
            "[0:v][1:v]overlay=0:0:format=auto[v]",
            "-map", "[v]",
            "-map", "0:a?",
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "18",
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart",
            output_path,
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print("FFmpeg error:")
            print(result.stderr[-2000:])
            sys.exit(1)

    print(f"\n✅ Done! Output: {output_path}")


# ──────────────────────────────────────────────
# DEMO: generate a test video with fake transcript
# ──────────────────────────────────────────────

def make_demo_video(output_dir: str = "."):
    """Create a demo video with a color background to test caption styles."""
    import random

    # 1. Generate a 10-second solid color test video
    test_video = os.path.join(output_dir, "demo_source.mp4")
    subprocess.run([
        "ffmpeg", "-y", "-f", "lavfi",
        "-i", "color=c=0x1a1a2e:size=1080x1920:rate=30",
        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100",
        "-t", "10",
        "-c:v", "libx264", "-c:a", "aac",
        test_video
    ], check=True, capture_output=True)

    # 2. Fake Whisper transcript
    sample_words = [
        ("This", 0.5, 0.8), ("is", 0.85, 1.0), ("how", 1.05, 1.3),
        ("Velora", 1.35, 1.8), ("builds", 1.85, 2.1), ("captions", 2.15, 2.7),
        ("that", 2.8, 3.0), ("look", 3.05, 3.3), ("amazing", 3.35, 3.9),
        ("on", 4.0, 4.15), ("TikTok", 4.2, 4.7), ("and", 4.8, 4.95),
        ("Reels", 5.0, 5.5), ("every", 5.8, 6.1), ("single", 6.15, 6.5),
        ("time", 6.55, 7.0), ("no", 7.3, 7.5), ("manual", 7.55, 7.9),
        ("editing", 7.95, 8.4), ("required", 8.5, 9.0),
    ]
    words = [Word(t, s, e) for t, s, e in sample_words]

    # 3. Render each style
    for style_name, style in STYLES.items():
        out_path = os.path.join(output_dir, f"demo_{style_name}.mp4")
        print(f"\n=== Rendering style: {style_name} ===")
        burn_captions(test_video, words, out_path, style)

    print(f"\n🎬 Demo videos saved to: {output_dir}")
    print("Styles rendered: " + ", ".join(STYLES.keys()))


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Velora Caption Engine")
    parser.add_argument("--video", help="Input video file")
    parser.add_argument("--whisper", help="Whisper JSON with word timestamps")
    parser.add_argument("--output", help="Output video file", default="output.mp4")
    parser.add_argument("--style", choices=list(STYLES.keys()), default="tiktok",
                        help="Caption style preset")
    parser.add_argument("--max-words", type=int, default=None,
                        help="Override max words per group")
    parser.add_argument("--demo", action="store_true",
                        help="Generate demo videos for all styles")
    args = parser.parse_args()

    if args.demo:
        make_demo_video("/mnt/user-data/outputs")
        return

    if not args.video or not args.whisper:
        parser.print_help()
        sys.exit(1)

    style = STYLES[args.style]
    words = load_whisper_words(args.whisper)
    burn_captions(args.video, words, args.output, style, args.max_words)


if __name__ == "__main__":
    main()
